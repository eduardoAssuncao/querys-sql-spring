package com.devsuperior.uri2609.projections;

public interface CategorySumProjection {

	String getName();
	Long getSum();
}

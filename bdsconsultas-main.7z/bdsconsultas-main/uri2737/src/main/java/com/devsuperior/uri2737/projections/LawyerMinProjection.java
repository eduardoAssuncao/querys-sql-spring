package com.devsuperior.uri2737.projections;

public interface LawyerMinProjection {

	String getName();
	Integer getCustomersNumber();
}

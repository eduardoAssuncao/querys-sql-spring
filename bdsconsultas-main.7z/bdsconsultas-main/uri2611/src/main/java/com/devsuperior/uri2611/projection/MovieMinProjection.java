package com.devsuperior.uri2611.projection;

public interface MovieMinProjection {

    Long getId();
    String getname();
}

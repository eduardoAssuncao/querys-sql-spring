package com.devsuperior.uri2621.projections;

public interface ProductMinProjection {

    String getName();
}

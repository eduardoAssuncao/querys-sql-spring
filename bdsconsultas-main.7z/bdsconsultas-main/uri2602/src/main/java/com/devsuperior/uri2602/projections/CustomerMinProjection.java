package com.devsuperior.uri2602.projections;

public interface CustomerMinProjection {

    String getName();
}
